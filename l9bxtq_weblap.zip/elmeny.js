function nagyBetu() {
    let theme = document.getElementById('alap_stilus');
    theme.href = "nagybetu.css";
}

function Alap() {
    let theme = document.getElementById('alap_stilus');
    theme.href = "stilus.css";
}